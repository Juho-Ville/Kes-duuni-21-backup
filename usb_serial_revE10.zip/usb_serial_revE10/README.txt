USB serial revE10
Author: Juho-Ville Koivistoinen

Notes for future revisions:
-Flooding of copper planes needs to be done again. The flooding has disappeared from the layout file.
-PCB outline needs to be modified (smaller length). The PCB is cut with iron saw in built versions.
-"USB serial revE10" silkscreen paint is flipped in delivered pcb:s, why?
-TR2024S3V3 footprint needs to be fixed (left most and right most pins need to switch places). This results in some rerouting.
